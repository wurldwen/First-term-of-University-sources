#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
using namespace std;

int main()
{
	int x[10] = {-1, -2, -3 -4, -5, 1, 2, 3, 4, 5};
	int i;
	fstream outFile;
	outFile.open("05.bin", ios::out | ios::binary);
	if (!outFile){
		exit(1);
	}
	
	outFile.write((char *)x,  sizeof(x));
	outFile.close();
    return 0;
}
