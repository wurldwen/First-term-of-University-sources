/*------------------------------------------------
    Filename:StructDemoCPP.h
    Purpose: Define Data struct declear function
             etc.
    Date��2018.4.26
------------------------------------------------*/
#ifndef __STRUCTDEMOCPP_H__
#define __STRUCTDEMOCPP_H__

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <algorithm>
using namespace std;

#define DEBUG
#define FILEOERROR 1
#define FILERERROR 2
#define FILEWERROR 3
#define STUNUM  84

struct Stud
{
    long lStuID;        //ѧ��
    char szName[20];    //����
    char szNCName[20];  //��Ȼ��
    char szTCName[20];  //��ѧ��
    char szCoName[20];  //�γ�����
    float fScore[4];    //�ɼ�
};

int  iGetData(struct Stud *);//Get data from file stinf.csv
void DisplayData(struct Stud *,int);//Display data
int Save2File(const char *, Stud *, int);//Save data to file

template <class T>
int iCompareT (T &, T &);

#endif // __STRUCTDEMOCPP_H__
