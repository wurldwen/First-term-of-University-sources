/*-----------------------------------------------
  Filename:StructDemoCPP.cpp
  Purpose: Processing StInfo.csv data etc.
  Date:2021.11.26
-----------------------------------------------*/
#include "StructDemoCPP.h"

int main(void){
    
    Stud stInf[STUNUM];
    int iErrCode;
    int i;

    iErrCode = iGetData(stInf);
    if(iErrCode == FILEOERROR)
    {
        cout << "File open error! press ant key exit!\n";
        system("pause");
        return FILEOERROR;
    }

    for(i = 0; i < STUNUM; i++)
    {
        stInf[i].fScore[3] = stInf[i].fScore[0] * 0.5f + stInf[i].fScore[1] * 0.3f + stInf[i].fScore[2] * 0.2f;
    }
    //DisplayData(stInf,1);
    
    sort(stInf,stInf + STUNUM,iCompareT <Stud>);
    cout << "--------------Sorted----------------" << endl;
    DisplayData(stInf,5);
    Save2File("S.csv", stInf, STUNUM);
    
    return 0;
}

/*-----------------------------------------------
  Name: iGetData
  Purpose:get struct data from file StInf.csv
  Arguments:struct stu *stp
  Return:int status of file open
           0:normal
           1:file open error
-----------------------------------------------*/
int iGetData(Stud *stp)
{
    int i;
    string StrLine, SubStr;
    fstream inFile("StInf.csv", ios::in);
    if(!inFile){
        return FILEOERROR;
    }
    inFile >> StrLine;//read title of .csv
    cout << StrLine << endl;
    while(inFile >> StrLine){
        istringstream sstr(StrLine);
        getline(sstr, SubStr, ',');
        stp -> lStuID = stol(SubStr);

        getline(sstr, SubStr, ',');
        strcpy(stp -> szName, SubStr.c_str());

        getline(sstr, SubStr, ',');
        strcpy(stp -> szNCName,SubStr.c_str());

        getline(sstr, SubStr, ',');
        strcpy(stp -> szTCName,SubStr.c_str());
        
        getline(sstr, SubStr, ',');
        strcpy(stp -> szCoName,SubStr.c_str());
        for(i = 0; i < 3; i++)
        {
            getline(sstr, SubStr, ',');
            stp -> fScore[i] = stof(SubStr);
        }
#ifdef DEBUG
        cout << stp -> lStuID << ":" << stp -> szName << ":";
        cout << stp -> szNCName << ":" << stp -> szTCName << ":";
        cout << stp -> szCoName <<" ";
        for(i = 0; i < 3; i++)
        {
            cout << ":" << stp -> fScore[i];
        }
        cout << endl;
#endif // DEBUG
        stp++;
    }
    inFile.close();
    return 0;
}

/*-----------------------------------------------
  Name:DisplayData
  Purpose:Display struct data
  Arguments:struct stu *stp,
            int iNum elements number
  Return: non
----------------------------------------------*/
void DisplayData(Stud *stp, int iNum)
{
    int i,j;
    cout << fixed << setprecision(1);
    for(i = 0;i < iNum;i++)
    {
        cout << setw(12) << stp[i].lStuID;
        cout << setw(7) << stp[i].szName;
        cout << setw(12) << stp[i].szNCName;
        cout << setw(14) << stp[i].szTCName;
        cout << setw(10) << stp[i].szCoName;
        for(j = 0; j < 4; j++)
        {
            cout << setw(6) << stp[i].fScore[j];
        }
        cout << endl;
    }
}

/*-----------------------------------------------
  Name: iComareT
  Purpose:Compare Templete function for sort()
  Arguments:T &Argu1,reference of first T
            T &Argu2 reference of second T
  Return: int compare result.
----------------------------------------------*/
template <class T>
int iCompareT(T &Argu1, T &Argu2){
    return Argu1.fScore[3] > Argu2.fScore[3];
}

/*-----------------------------------------------
  Name: Save2
  Purpose: Save to the file.csv.
  Arguments: const char *szFileName, Filename
             Stud *pStuT Address of Stud data.
             int Num The number of Stud.
  Return: int File open | write errorcode.
----------------------------------------------*/
int Save2File(const char *szFileName, Stud *pStu, int Num){
    fstream OutFile(szFileName, ios::out);
    if (!OutFile){
        return FILEOERROR;
    }
    OutFile << "ѧ��,����,������,��ѧ�����,�γ�����,��ĩ����,���ò���,��ҵ׫д,�ܷ�\n";

    for (int i = 0; i < Num; ++i){
        OutFile << pStu[i].lStuID << "," << pStu[i].szName << ",";
        OutFile << pStu[i].szNCName << "," << pStu[i].szTCName << ",";
        OutFile << pStu[i].szCoName << ",";
        for (int j = 0; j < 3; ++j){
            OutFile << pStu[i].fScore[j] << ",";
        }
        OutFile << pStu[i].fScore[3] << endl;
    }

    OutFile.close();
    return 0;
}