#include <iostream>
#include <fstream>
#include <algorithm>
#include <cstdlib>

using namespace std;

template <class T>
int CompT(const T &, const T &);

int main(void){
	ifstream inFile;
	int *ipBuff, iNum;
	int i;
	inFile.open("sdata.txt", ios::in);
	if (!inFile){
		cout << "File open error!" << endl;
		exit(2);
	}
	ofstream outFile("ddata.txt", ios::out);
	if (!outFile){
		cout << "File open error!" << endl;
		inFile.close();
		exit(3);
	}
	inFile >> iNum;
	cout  << iNum << endl;
	
	if(iNum > 0){
		ipBuff = new int[iNum];
		if (ipBuff == NULL){
			cout << "Memory alloction error!" << endl;
			inFile.close();
			outFile.close();
			exit(1);
		}
	}

	for (i = 0; i  < iNum && inFile >> ipBuff[i]; ++i){
		;
	}
	iNum = i;
	cout  << iNum << endl;
	sort(ipBuff, ipBuff + iNum, CompT<int>);
	
    outFile << iNum << endl;
	for (i = 0; i < iNum; ++i){
		outFile << ipBuff[i] << " ";
	}
		
	delete [] ipBuff;
	outFile.close();
	inFile.close();
    return 0;
}

template <class T>
int CompT(const T &a, const T &b){
	return a > b;
}