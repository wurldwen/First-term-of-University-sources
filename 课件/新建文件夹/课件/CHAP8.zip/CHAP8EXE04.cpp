#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdlib>

using namespace std;

const int N = 5;

struct student
{
	long lNum;
	char name[20];
	float fScore[3];
	float fAve;
	float fSum;
};

int main(void){
	student stBuff[N], stTmp;
	fstream inFile, outFile;
	int i, j;

	inFile.open("Stus.txt", ios::in);
	if (!inFile){
		cout << "Source file open error!";
		exit(1);
	}

	outFile.open("Stud.txt", ios::out);
	if (!outFile){
		cout << "Destination file open error!";
		inFile.close();
		exit(2);
	}


	for (i = 0; i < N; i++)
	{
		inFile >> stBuff[i].lNum >> stBuff[i].name;
        inFile >> stBuff[i].fScore[0] >> stBuff[i].fScore[1] >> stBuff[i].fScore[2];
		stBuff[i].fSum = stBuff[i].fScore[0] + stBuff[i].fScore[1] + stBuff[i].fScore[2];
		stBuff[i].fAve = stBuff[i].fSum / 3.0f;
	}

	for (i = 0;i < N - 1; i++)
	{
		for (j = i + 1; j < N ; j++)
		{
			if (stBuff[i].fSum < stBuff[j].fSum)
			{
				stTmp = stBuff[i];
				stBuff[i] = stBuff[j];
				stBuff[j] = stTmp;
			}

		}
	}

	for (i = 0; i < N; i++)
	{
	    outFile << stBuff[i].lNum << " " << stBuff[i].name;
		for (j = 0; j < 3; j++)
		{
		    outFile << fixed << setprecision(1) << setw(7) << stBuff[i].fScore[j];
		}
		outFile << fixed << setprecision(1) << setw(7) << stBuff[i].fAve;
		outFile << fixed << setprecision(1) << setw(7) << stBuff[i].fSum << endl;
	}

	inFile.close();
	outFile.close();

	return 0;
}
