#include <iostream>
#include <fstream>
#include <cstdlib>

using namespace std;

int main(void){
    fstream file;
    char msg[ ] = "This is a test message", buf[20];
   
    file.open("Test.txt", ios::out | ios::in | ios::trunc | ios::binary);
    
    if (!file){
        cout << "File open failed" << endl;
        exit(1);
    }
    
    file.write(msg, sizeof(msg));
   
    file.seekp(0, ios::beg);
    file.read(buf, 20);
    cout << file.gcount() << endl;
    cout << buf << endl;

    file.close();

    return 0;
}
