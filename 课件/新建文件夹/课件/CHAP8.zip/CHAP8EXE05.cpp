#include <iostream>     // std::cout
#include <fstream>      // std::ifstream
using namespace std;

int main(void){
    fstream OutFile;
    char szMessage[] = "This a test message!";
    char szBuff[80];
    int i;

    OutFile.open("94.bin", ios::out | ios :: binary);

    if (!OutFile){
        cout << "File open failed.";
        exit(1);
    }

    OutFile.write(szMessage, sizeof(szMessage));
    OutFile.close();
    /*
    fstream inFile("94.bin", ios::in | ios::binary);
    if(!inFile){
        cout << "File open failed.";
        exit(2);
    }*/

    return 0;
}
