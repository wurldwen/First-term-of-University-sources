#include <iostream>
#include <fstream>
#include <cstdlib>

using namespace std;

int main(void){
	char szBuff[80];
	ifstream inFile;
	inFile.open("in.txt", ios::in);
	if (!inFile){
		cout << "File open error!" << endl;
		exit(2);
	}

	inFile.getline(szBuff, 80);
	cout << szBuff << endl;
	
	ofstream outFile("E:\\out.txt", ios::out);
	if (!outFile){
		cout << "File open error!" << endl;
		
		system("pause");
		inFile.close();
		exit(1);
	}

	outFile << szBuff  << endl;	
	
	outFile.close();
	inFile.close();
    return 0;
}