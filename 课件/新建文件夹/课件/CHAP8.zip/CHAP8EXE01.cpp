#include <iostream>
#include <fstream>
#include <cstdlib>

using namespace std;

int main(void){
	ifstream inFile;
	char szBuff[80];
	inFile.open("in.txt", ios :: in );
	if (!inFile){
		cout << "File open error!" << endl;
		exit(2);
	}

	// if (inFile >> szBuff){
		
	// 	cout << szBuff << endl;
	// }
	// if (inFile >> szBuff){
	// 	cout << szBuff << endl;
	// }
	// if (inFile >> szBuff){
	// 	cout << szBuff << endl;
	// }
	
	inFile.getline(szBuff, 80);
	cout << szBuff << endl;
	inFile.getline(szBuff, 80);
	cout << szBuff << endl;
	
	inFile.close();
    return 0;
}
