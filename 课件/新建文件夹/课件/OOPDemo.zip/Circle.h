#ifndef __CIRCLE_H__
#define __CIRCLE_H__

#include <iostream>
#include <iomanip>

using namespace std;

class Circle
{
    public:
        static double const PI;
        Circle(double dArgu  = 1.0);
        double getArea();
        double getPerimeter();
        void setRadius(double dArgu){
            dRadius = dArgu;
        }
        double getRadius(void){
            return dRadius;
        }
        virtual ~Circle(){
            cout << "The object has destroyed" << endl;
        };

    protected:

    private:
        double dRadius;
};

const double Circle::PI = 3.141592653589323;

Circle::Circle(double dArgu){
    dRadius = dArgu;
}

double Circle::getPerimeter(void){
    return Circle::PI * dRadius * 2.0;
}

double Circle::getArea(void){
    return PI * dRadius * dRadius;
}

#endif // __CIRCLE_H__
