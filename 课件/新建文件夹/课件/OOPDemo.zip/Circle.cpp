#include "Circle.h"

int main(void){
    Circle c1(5);
    cout << setw(20) << setprecision(10) << c1.getArea() << endl;
    Circle c[10];
    for(int i = 0; i < 10; i++){
       double dVal = (c + i) -> getPerimeter();
        cout << setw(20) << dVal << endl;
    }

    
    cout << setw(20) << Circle::PI << endl;
    
    return 0;
}
